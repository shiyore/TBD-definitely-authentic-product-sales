<?php
namespace App\Services\Data;
use App\Models\PortfolioModel;
use App\Models\UserModel;
use Carbon\Exceptions\Exception;

class PortfolioDAO
{
    private $conn;
    
    public function __construct(DBConnect $db)
    {
        $this->conn = $db->get_conn();
    }
    
    public function checkPortfolio(PortfolioModel $port)
    {
        try 
        {
            $query = "SELECT * FROM portfolios WHERE username = '{$port->getName()}'";
            
            $result = mysqli_query($this->conn , $query);
            if(mysqli_num_rows($result) > 0){
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return true;
            }else{
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return false;
            }
        } 
        catch (Exception $e) 
        {
            echo $e->getMessage();
            echo '<h2>Exception in check portfolio</h2>';
        }
    }
    
    public function updatePortfolio(PortfolioModel $port)
    {
        try
        {
            $query = "UPDATE portfolios SET position = '{$port->getPosition()}', experience = '{$port->getExperience()}', proficiencies = '
                      {$port->getProficiencies()}' WHERE username = '{$port->getName()}'";
            $result = mysqli_query($this->conn, $query);
        }
        catch (Exception $e)
        {
            echo $e->getMessage();
        }
    }
    
    public function createPortfolio(PortfolioModel $port)
    {
        try
        {
            $query = "INSERT INTO portfolios VALUES username = '{$port->getName()}' position = '{$port->getPosition()}', 
                      experience = '{$port->getExperience()}', proficiencies = '{$port->getProficiencies()}'";
            echo '<h2>In create portfolio</h2>';
                      
            if ($result = mysqli_query($this->conn, $query))
            {
                echo '<h2>True</h2>';
                return true;
            }
            else
            {
                echo '<h2>False</h2>';
                return false;
            }
        }
        catch (Exception $e)
        {
            echo $e->getMessage();
        }
    }
}
?>