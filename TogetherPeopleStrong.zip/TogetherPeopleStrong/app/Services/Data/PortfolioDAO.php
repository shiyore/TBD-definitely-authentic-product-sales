<?php
namespace App\Services\Data;
use App\Models\PortfolioModel;
use App\Models\UserModel;
use Carbon\Exceptions\Exception;

class PortfolioDAO
{
    private $conn;
    
    public function __construct(DBConnect $db)
    {
        $this->conn = $db->get_conn();
    }
    
    public function checkPortfolio(PortfolioModel $port)
    {
        try 
        {
            $query = "SELECT * FROM portfolios WHERE username = '{$port->getUser()->getUsername()}'";
            
            $result = mysqli_query($this->conn , $query);
            if(mysqli_num_rows($result) > 0){
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return true;
            }else{
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return false;
            }
        } 
        catch (Exception $e) 
        {
            echo $e->getMessage();
        }
    }
    
    public function updatePortfolio(PortfolioModel $port)
    {
        try
        {
            $query = "UPDATE portfolios SET position = '{$port->getPosition()}', experience = '{$port->getExperience()}', proficiencies = '
                      {$port->getProficiencies()}' WHERE username = '{$port->getUser()->getUsername()}'";
            $result = mysqli_query($this->conn, $query);
        }
        catch (Exception $e)
        {
            echo $e->getMessage();
        }
    }
    
    public function createPortfolio(PortfolioModel $port)
    {
        try
        {
            $query = "INSERT INTO portfolios VALUES username = '{$port->getUser()->getUsername()}' position = '{$port->getPosition()}', 
                      experience = '{$port->getExperience()}', proficiencies = '{$port->getProficiencies()}'";
                      
            $result = mysqli_query($this->conn, $query);
        }
        catch (Exception $e)
        {
            echo $e->getMessage();
        }
    }
}
?>