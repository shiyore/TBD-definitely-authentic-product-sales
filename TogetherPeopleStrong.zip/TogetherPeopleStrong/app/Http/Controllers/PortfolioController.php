<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\Businesses\SecurityService;
use App\Models\AdminModel;
use App\Models\UserModel;
use App\Models\PortfolioModel;
use App\Services\Businesses\PortfolioService;

class PortfolioController extends Controller
{
    public function update(Request $request)
    {
        $user = new UserModel(request()->get('user_name'), request()->get('email'), request()->get('password'));
        $portfolio = new PortfolioModel($user, request()->get('position'), request()->get('experience'), request()->get('proficiencies'));
        
        $service = new PortfolioService();
        
        $exists = $service->checkPortfolio($user);
        
        if ($exists)
        {
            $service->updatePortfolio($portfolio);
        }
        else 
        {
            $service->createPortfolio($portfolio);
        }
    }
}